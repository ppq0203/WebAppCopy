<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
	<title>Software Engineering Lab - Notice</title>
	<!--[if IE]>
	<script src="https://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" type="text/css" />
	<link rel="stylesheet" href="/common/styles/reset-1.6.1.css" type="text/css" />
	<link rel="stylesheet" href="/common/styles/jquery-ui.css" type="text/css" />
	<link rel="stylesheet" href="/common/styles/font-awesome-4.0.3/css/font-awesome.min.css" type="text/css" />
	<link rel="stylesheet" href="/common/styles/common.css" type="text/css" />
	<link rel="shortcut icon" href="/common/images/SelabFavicon.png" type="image/png">
			<link rel="stylesheet" href="styles/notice.css" type="text/css" />
		
	<script type="text/javascript" src="/common/scripts/jquery-1.11.0.min.js"></script>
	<script type="text/javascript" src="/common/scripts/jquery-ui.js"></script>
	<script type="text/javascript" src="/common/scripts/buffered-keyup.js"></script>
	<script type="text/javascript" src="/common/scripts/common.js"></script>
			<script type="text/javascript" src="scripts/notices.js"></script>
		
</head>

<body>
	<header role="banner">
		<div class="container">
			<nav role="navigation">
				<div id="logo" class="pull-left"><a href="/"><img src="/common/images/selab_logo_S.png" /></a></div>
				<ul id="menu" class="inline-list pull-left">
					<li class="pull-left"><a href="/notice" class='selected'>NOTICE</a></li>
					<li class="pull-left"><a href="/members" >MEMBERS</a></li>
					<li class="pull-left"><a href="/research" >RESEARCH</a></li>
					<li class="pull-left"><a href="/publications" >PUBLICATIONS</a></li>
					<li class="pull-left"><a href="/courses" >COURSES</a></li>
					<li class="pull-left"><a href="/gallery" >GALLERY</a></li>
									</ul>
							<div role="login" class="pull-right">
											<a href="/login/index.php?source=/notice/index.php">LOGIN</a>            
										</div>
				<a id="contact" href="/contact" class='pull-right'>CONTACT</a>
			</nav>
		</div>
	</header>

	<main role="main">
		<div class="container">
			<div class="contents">
					<div id="information">
		<h1>NOTICE<a href="rss.php"><i class="fa fa-rss-square"></i></a></h1>
			</div>

	<ul id="board">
		<li class="header">
			<ul>
				<li class="title pull-left">Title</li>
				<li class="name pull-left">Name</li>
				<li class="time pull-left">Date</li>
			</ul>
		</li>
		 
		<li class="entry">
			<div class="information">
				<ul>
					<li class="title pull-left">연구원 모집</li>
					<li class="name pull-left">Scott Uk-Jin Lee</li>
					<li class="time pull-left">29 Aug 2014</li>
									</ul>
			</div>
			<div class='content hidden'>
				<p>SELab에서는 소프트웨어공학 전 분야, 멀티쓰레드 소프트웨어 및 웹 기술을 함께 연구할 석사, 박사, 석박통합 및 박사후 과정의 연구원을 모집하고 있습니다. <br /><br />현재 SELab에서는 미래창조과학부 주체 NIPA주관의 대규모 프로젝트에 활발히 참여하고 있으며 이를 통하여 연구원들의 연구가 원활히 진행될 수 있도록 프로젝트 인건비를 지원하고 있습니다. 이 밖에도 연구조교, 교육조교 장학금 외 다양한 장학금을 지원하고 있으며 입학시 쾌적한 연구공간과 연구 장비 (PC/iMac 등) 지원도 하고 있습니다. <br /><br />SELab 연구 분야에 관심이 있으신 분은 아래로 연락주세요! <br /><br />한양대학교 ERICA 제 3공학관 403호, 421호 <br />scottlee@hanyang.ac.kr <br />031-400-5238 / 031-400-4754</p>
							</div>
		</li>
		 
		<li class="entry">
			<div class="information">
				<ul>
					<li class="title pull-left">2014 PL-SE First Joint Workshop</li>
					<li class="name pull-left">Scott Uk-Jin Lee</li>
					<li class="time pull-left">29 Apr 2014</li>
									</ul>
			</div>
			<div class='content hidden'>
				<p>PLASSE &amp; SE Lab. in the CSE Dept. @ HYU are organizing the 1st Joint Workshop in the Spring of 2014. <br /><br />2:00pm - 6:00pm, 10th of May, 2014 @ Engineering Building No.3 Room 315</p>
									<p class="attachement">
						Attachment : <a href="download.php?filename=12014_04_29_20_20_53^PL-SE_1st schedule.pdf">PL-SE_1st schedule.pdf</a>
					</p>
							</div>
		</li>
		 
		<li class="entry">
			<div class="information">
				<ul>
					<li class="title pull-left">Welcome to SELab Homepage!</li>
					<li class="name pull-left">Scott Uk-Jin Lee</li>
					<li class="time pull-left">06 Mar 2014</li>
									</ul>
			</div>
			<div class='content hidden'>
				<p>Welcome to Software Engineering Laboratory Homepage. <br /><br />Software Engineering Laboratory is  <br />- within Dept. of Computer Science and Engineering at Hanyang University, South Korea <br />- established in Sept. 2011 <br /><br />The current version (ver2.0) of SELab Web Site is launched in Feb. 2014. </p>
							</div>
		</li>
			</ul>
	<span id="end"></span>
				</div>
		</div>
	</main>

	<footer role="contentinfo">
		<div class="container">
			<p>COPYRIGHT 2014 SELAB, ALL RIGHTS RESERVED. COMPUTER SCIENECE AND ENGINEERING, HANYANG UNIV. LOCATION: ENGINEERING BUILDING #3, ROOM 421. T +82-31-400-4754</p>
		</div>
	</footer>
</body>
</html>
