<!DOCTYPE html>
<html>
	<!-- CSE3026, Fall 2015 - "Quote of the Day" Ajax example -->
	
	<head>
		<title>Quote of the Day</title>
		<meta charset="UTF-8" />
	</head>	
		
	<body>
		<h1>CSE 3026 - Quote of the Day</h1>
		
		<article>
			<section>
				<blockquote>
						<p>I _am_ pragmatic. That which works, works, and theory can go screw itself.
However, my pragmatism also extends to maintainability, which is why I also
want it done well.
	-- Linus</p>

				</blockquote>
			</section>
		</article>
	</body>
</html>
			